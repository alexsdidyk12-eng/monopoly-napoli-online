const fs=require('fs'),express=require('express'),http=require('http'),{Server}=require('socket.io');
const app=express(),srv=http.createServer(app),io=new Server(srv);
app.use(express.static(__dirname+'/public'));app.get('/r/:c',(q,r)=>r.sendFile(__dirname+'/public/index.html'));
const HC=[50,50,100,100,150,150,200,200],GC=[0x8b5a2b,0x8fd3f4,0xd6409f,0xf28c28,0xd62828,0xf5d423,0x1f9d55,0x1f4fbf],COL=[0xe63946,0x2a9d8f,0xf4a261,0x457b9d,0x9b5de5,0xf1c40f,0x06d6a0,0xff70a6],SH=['Конус','Цилиндр','Шар','Куб','Тор','Октаэдр','Додекаэдр','Тетраэдр'];
const st=(n,g,p,r)=>[n,'s',g,p,r];
const T=[['СТАРТ','g'],st('Via Forcella',0,60,[2,10,30,90,160,250]),['Общ. казна','k'],st('Via Tribunali',0,60,[4,20,60,180,320,450]),['Налог на доход','t',200],['Stazione Centrale','r'],
st('Spaccanapoli',1,100,[6,30,90,270,400,550]),['Шанс','c'],st('Via Chiaia',1,100,[6,30,90,270,400,550]),st('Via Toledo',1,120,[8,40,100,300,450,600]),['Тюрьма','j'],
st('Piazza Bellini',2,140,[10,50,150,450,625,750]),['Elettricità','u'],st('Via Caracciolo',2,140,[10,50,150,450,625,750]),st('Piazza Dante',2,160,[12,60,180,500,700,900]),['Stazione Garibaldi','r'],
st('Mergellina',3,180,[14,70,200,550,750,950]),['Общ. казна','k'],st('Posillipo',3,180,[14,70,200,550,750,950]),st('Vomero',3,200,[16,80,220,600,800,1000]),['Бесплатная стоянка','p'],
st('Quartieri Spagnoli',4,220,[18,90,250,700,875,1050]),['Шанс','c'],st('Sanità',4,220,[18,90,250,700,875,1050]),st('Piazza del Plebiscito',4,240,[20,100,300,750,925,1100]),['Stazione Mergellina','r'],
st('Castel dell’Ovo',5,260,[22,110,330,800,975,1150]),st('Castel Nuovo',5,260,[22,110,330,800,975,1150]),['Acquedotto','u'],st('Teatro San Carlo',5,280,[24,120,360,850,1025,1200]),['В тюрьму','x'],
st('Galleria Umberto I',6,300,[26,130,390,900,1100,1275]),st('Piazza Municipio',6,300,[26,130,390,900,1100,1275]),['Общ. казна','k'],st('Lungomare',6,320,[28,150,450,1000,1200,1400]),['Stazione Piscinola','r'],
['Шанс','c'],st('Palazzo Reale',7,350,[35,175,500,1100,1300,1500]),['Налог на роскошь','t',75],st('Villa Comunale',7,400,[50,200,600,1400,1700,2000])];
const CH=[['Вперёд на СТАРТ (+$200)','g',0],['Идите на Piazza del Plebiscito','g',24],['Идите на Piazza Bellini','g',11],['Ближайшая коммунальная: купите или заплатите 10× кубики','u'],['Ближайшая станция: двойная аренда','r'],['Ближайшая станция: двойная аренда','r'],['Дивиденды банка: +$50','m',50],['Карта «Освобождение из тюрьмы»','f'],['Назад на 3 клетки','b'],['Отправляйтесь в тюрьму','j'],['Ремонт: $25 за дом, $100 за отель','h',25,100],['Штраф за бедность: $15','m',-15],['Поездка на Stazione Centrale','g',5],['Идите на Villa Comunale','g',39],['Вы председатель: заплатите каждому $50','e',50],['Заём вернулся: +$150','m',150]];
const CC=[['Вперёд на СТАРТ (+$200)','g',0],['Ошибка банка в вашу пользу: +$200','m',200],['Врач: −$50','m',-50],['Продажа акций: +$50','m',50],['Карта «Освобождение из тюрьмы»','f'],['Отправляйтесь в тюрьму','j'],['Вечер в опере: +$50 от каждого','c',50],['Праздничный фонд: +$100','m',100],['Возврат налога: +$20','m',20],['День рождения: +$10 от каждого','c',10],['Страховка: +$100','m',100],['Больница: −$100','m',-100],['Школа: −$50','m',-50],['Консультация: +$25','m',25],['Ремонт улиц: $40 за дом, $115 за отель','h',40,115],['Конкурс красоты: +$10','m',10],['Наследство: +$100','m',100]];
const rooms={},SAVE=__dirname+'/rooms.json';
try{Object.assign(rooms,JSON.parse(fs.readFileSync(SAVE)));Object.values(rooms).forEach(R=>R.P.forEach(p=>p.on=0))}catch{}
const save=()=>fs.writeFile(SAVE,JSON.stringify(rooms),()=>{});setInterval(save,5000);
process.on('SIGINT',()=>{fs.writeFileSync(SAVE,JSON.stringify(rooms));process.exit()});
const rnd=n=>1+Math.floor(Math.random()*n),shuf=a=>{for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
const ty=i=>T[i][1],price=i=>ty(i)=='s'?T[i][3]:ty(i)=='r'?200:150,grp=i=>T[i][2];
const gi=g=>T.map((_,i)=>i).filter(i=>ty(i)=='s'&&grp(i)==g);
const pl=(R,id)=>R.P.find(p=>p.id==id),cur=R=>R.P[R.t],lg=(R,m)=>{R.log.push(m);R.log.length>80&&R.log.shift()};
const mono=(R,i,o)=>gi(grp(i)).every(j=>R.B[j].o==o);
const hs=R=>32-R.B.filter(b=>b.h>0&&b.h<5).reduce((a,b)=>a+b.h,0),ht=R=>12-R.B.filter(b=>b.h==5).length;
const fx=(R,id,a)=>{R.fx.push({n:++R.fn,id,a});R.fx.length>10&&R.fx.shift()};
const bld=(R,i)=>ty(i)=='s'&&gi(grp(i)).some(j=>R.B[j].h);
const mk=code=>({code,ph:'lobby',P:[],B:T.map(()=>({o:null,h:0,m:0})),t:0,tp:'roll',dc:0,d:[1,1],rid:0,mv:null,pend:null,debt:null,trade:null,card:null,fx:[],fn:0,log:[],dk:{c:[],k:[]},win:null,mult:1,uid:0});
const pub=R=>({...R,dk:undefined,uid:undefined,P:R.P.map(({tok,ln,...x})=>x),hs:hs(R),ht:ht(R)});
const bc=R=>io.to(R.code).emit('state',pub(R));
function charge(R,p,a,to){const q=to&&pl(R,to);
 if(p.cash>=a){p.cash-=a;if(q)q.cash+=a;fx(R,p.id,-a);if(q)fx(R,q.id,a);return 1}
 R.debt={id:p.id,amt:a,to:to||null};lg(R,`${p.name} должен $${a}: заложите/продайте имущество или объявите банкротство`);return 0}
function settle(R){const d=R.debt;if(!d)return;const p=pl(R,d.id);if(p.cash>=d.amt){R.debt=null;charge(R,p,d.amt,d.to)}}
function next(R){do R.t=(R.t+1)%R.P.length;while(R.P[R.t].out);R.tp='roll';R.dc=0;R.mv=null;lg(R,`Ход: ${cur(R).name}`)}
function broke(R,p,to){const q=to&&pl(R,to);
 R.B.forEach((b,i)=>{if(b.o!=p.id)return;if(b.h){p.cash+=b.h*HC[grp(i)]/2;b.h=0}
  if(q){b.o=q.id;if(b.m)q.cash-=Math.min(q.cash,Math.ceil(price(i)/2*.1))}else{b.o=null;b.m=0}});
 if(q){q.cash+=p.cash;p.jf.forEach(c=>q.jf.push(c))}else p.jf.forEach(([k,c])=>R.dk[k].push(c));
 fx(R,p.id,-p.cash);p.cash=0;p.jf=[];p.out=1;R.debt=null;lg(R,`${p.name} обанкротился`);
 const al=R.P.filter(x=>!x.out);if(al.length==1){R.win=al[0].id;R.ph='over';lg(R,`Победитель: ${al[0].name}`);return}
 if(R.pend&&R.pend.t=='buy')R.pend=null;if(cur(R)===p){R.pend=null;next(R)}}
function jail(R,p){p.pos=10;p.jail=1;p.jt=0;R.dc=0;R.tp='act';R.mv={n:++R.fn,id:p.id,to:10,direct:1};lg(R,`${p.name} в тюрьме`)}
function go(R,p,to,fwd,direct){if(fwd&&to<p.pos){p.cash+=200;fx(R,p.id,200);lg(R,`${p.name} проходит СТАРТ +$200`)}
 R.mv={n:++R.fn,id:p.id,to,direct:direct?1:0,back:fwd?0:1};p.pos=to;land(R,p)}
function land(R,p){const i=p.pos,t=ty(i),b=R.B[i],mu=R.mult;R.mult=1;
 if('sru'.includes(t)){if(!b.o)R.pend={t:'buy',i};else if(b.o!=p.id&&!b.m){let r;
  if(t=='s')r=b.h?T[i][4][b.h]:T[i][4][0]*(mono(R,i,b.o)?2:1);
  else if(t=='r')r=25*2**(R.B.filter((x,j)=>ty(j)=='r'&&x.o==b.o).length-1)*mu;
  else r=(mu>1||R.B.filter((x,j)=>ty(j)=='u'&&x.o==b.o).length>1?10:4)*(R.d[0]+R.d[1]);
  lg(R,`${p.name} платит аренду $${r}`);charge(R,p,r,b.o)}}
 else if(t=='t'){lg(R,`${p.name}: налог $${T[i][2]}`);charge(R,p,T[i][2],null)}
 else if(t=='x')jail(R,p);else if(t=='k'||t=='c')card(R,p,t)}
function card(R,p,t){const k=t=='c'?'c':'k',D=R.dk[k],id=D.shift(),c=(k=='c'?CH:CC)[id],f=c[1],ot=R.P.filter(x=>!x.out&&x!==p);
 lg(R,`${p.name}: «${c[0]}»`);R.card={n:++R.fn,txt:c[0]};if(f=='f')p.jf.push([k,id]);else D.push(id);
 if(f=='g')go(R,p,c[2],1,1);else if(f=='b')go(R,p,(p.pos+37)%40,0);
 else if(f=='m'){if(c[2]>0){p.cash+=c[2];fx(R,p.id,c[2])}else charge(R,p,-c[2],null)}
 else if(f=='j')jail(R,p);
 else if(f=='h'){let s=0;R.B.forEach((b,i)=>{if(b.o==p.id)s+=b.h==5?c[3]:b.h*c[2]});if(s)charge(R,p,s,null)}
 else if(f=='e'){const s=c[2]*ot.length;if(p.cash>=s){ot.forEach(q=>{q.cash+=c[2];fx(R,q.id,c[2])});charge(R,p,s,null)}else charge(R,p,s,null)}
 else if(f=='c'){ot.forEach(q=>{const a=Math.min(q.cash,c[2]);q.cash-=a;p.cash+=a;fx(R,q.id,-a)});}
 else if(f=='u'){R.mult=10;go(R,p,[12,28].find(x=>x>p.pos)??12,1,1)}
 else if(f=='r'){R.mult=2;go(R,p,[5,15,25,35].find(x=>x>p.pos)??5,1,1)}}
function aucEnd(R){const a=R.pend,act=R.P.filter(p=>!p.out&&p.on&&!a.pass.includes(p.id));
 if(a.lead&&act.length<=1){const w=pl(R,a.lead);w.cash-=a.bid;fx(R,w.id,-a.bid);R.B[a.i].o=w.id;lg(R,`${w.name} выиграл аукцион за $${a.bid}`);R.pend=null}
 else if(!act.length){lg(R,'Аукцион без победителя');R.pend=null}}
const own=(R,p,i)=>R.B[i]&&R.B[i].o==p.id;
const A={
roll(R,p){if(cur(R)!==p||R.tp!='roll'||R.pend||R.debt)return 'Сейчас нельзя бросать';
 const d=[rnd(6),rnd(6)],dbl=d[0]==d[1],n=d[0]+d[1];R.d=d;R.rid++;R.card=null;lg(R,`${p.name} бросает ${d[0]}+${d[1]}`);
 if(p.jail){if(dbl){p.jail=0;R.tp='act';go(R,p,(p.pos+n)%40,1)}else if(++p.jt>=3){p.jail=0;R.tp='act';if(charge(R,p,50,null))go(R,p,(p.pos+n)%40,1)}else R.tp='act';return}
 R.dc=dbl?R.dc+1:0;
 if(R.dc==3){lg(R,'Три дубля подряд!');R.mv=null;jail(R,p)}else{R.tp=dbl?'roll':'act';go(R,p,(p.pos+n)%40,1)}},
buy(R,p){const x=R.pend;if(!x||x.t!='buy'||cur(R)!==p)return 'Нечего покупать';const c=price(x.i);if(p.cash<c)return 'Не хватает денег';
 p.cash-=c;fx(R,p.id,-c);R.B[x.i].o=p.id;R.pend=null;lg(R,`${p.name} купил ${T[x.i][0]} за $${c}`)},
decline(R,p){const x=R.pend;if(!x||x.t!='buy'||cur(R)!==p)return 'Нет';R.pend={t:'auc',i:x.i,bid:0,lead:null,pass:[]};lg(R,`Аукцион: ${T[x.i][0]}`);aucEnd(R)},
bid(R,p,m){const a=R.pend,v=Math.floor(m.amt);if(!a||a.t!='auc'||p.out||a.pass.includes(p.id))return 'Нет аукциона';if(!(v>a.bid)||v>p.cash)return 'Недопустимая ставка';a.bid=v;a.lead=p.id;aucEnd(R)},
pass(R,p){const a=R.pend;if(!a||a.t!='auc'||a.lead==p.id||a.pass.includes(p.id))return 'Нельзя';a.pass.push(p.id);aucEnd(R)},
end(R,p){if(cur(R)!==p||R.tp!='act'||R.pend||R.debt)return 'Нельзя завершить ход';next(R)},
payjail(R,p){if(cur(R)!==p||!p.jail||R.tp!='roll')return 'Нельзя';if(p.cash<50)return 'Не хватает денег';p.cash-=50;fx(R,p.id,-50);p.jail=0},
jailcard(R,p){if(cur(R)!==p||!p.jail||R.tp!='roll'||!p.jf.length)return 'Нельзя';const[k,c]=p.jf.pop();R.dk[k].push(c);p.jail=0},
build(R,p,m){const i=m.i,b=R.B[i];if(R.pend||!own(R,p,i)||ty(i)!='s')return 'Нельзя';const g=gi(grp(i));
 if(!mono(R,i,p.id)||g.some(j=>R.B[j].m)||b.h>=5||g.some(j=>R.B[j].h<b.h))return 'Нужна монополия, без залога, равномерно';
 if(b.h<4&&hs(R)<1)return 'Нет домов в банке';if(b.h==4&&ht(R)<1)return 'Нет отелей в банке';const c=HC[grp(i)];if(p.cash<c)return 'Не хватает денег';
 p.cash-=c;b.h++;fx(R,p.id,-c);lg(R,`${p.name}: ${b.h==5?'отель':'дом'} на ${T[i][0]}`)},
sell(R,p,m){const i=m.i,b=R.B[i];if(R.pend||!own(R,p,i)||!b.h)return 'Нет зданий';if(gi(grp(i)).some(j=>R.B[j].h>b.h))return 'Продавайте равномерно';
 if(b.h==5&&hs(R)<4)return 'В банке нет 4 домов для замены отеля';const c=HC[grp(i)]/2;p.cash+=c;b.h--;fx(R,p.id,c);lg(R,`${p.name} продал здание на ${T[i][0]}`)},
mort(R,p,m){const i=m.i,b=R.B[i];if(R.pend||!own(R,p,i)||b.m||bld(R,i))return 'Нельзя заложить';p.cash+=price(i)/2;b.m=1;fx(R,p.id,price(i)/2);lg(R,`${p.name} заложил ${T[i][0]}`)},
unmort(R,p,m){const i=m.i,b=R.B[i],c=Math.ceil(price(i)/2*1.1);if(R.pend||!own(R,p,i)||!b.m)return 'Нельзя';if(p.cash<c)return 'Не хватает денег';p.cash-=c;b.m=0;fx(R,p.id,-c);lg(R,`${p.name} выкупил ${T[i][0]}`)},
paydebt(R,p){if(!R.debt||R.debt.id!=p.id)return 'Нет долга';if(p.cash<R.debt.amt)return 'Не хватает денег';settle(R)},
bankrupt(R,p){if(!R.debt||R.debt.id!=p.id)return 'Банкротство только при долге';broke(R,p,R.debt.to)},
tradeP(R,p,m){if(R.trade||R.pend||R.debt)return 'Занято';const q=pl(R,m.to);if(!q||q.out||q===p)return 'Игрок';
 const gp=(m.gp||[]).map(Number),tk=(m.tk||[]).map(Number),gc=Math.floor(m.gc)||0,tc=Math.floor(m.tc)||0;
 if(gc<0||tc<0||gc>p.cash||tc>q.cash||!(gc||tc||gp.length||tk.length))return 'Неверные условия';
 if(gp.some(i=>!own(R,p,i)||bld(R,i))||tk.some(i=>!own(R,q,i)||bld(R,i)))return 'Нельзя: здания на группе';
 R.trade={from:p.id,to:q.id,gc,tc,gp,tk};lg(R,`${p.name} предлагает обмен ${q.name}`)},
tradeA(R,p){const t=R.trade;if(!t||t.to!=p.id)return 'Нет';const a=pl(R,t.from);
 if(a.cash<t.gc||p.cash<t.tc||t.gp.some(i=>!own(R,a,i)||bld(R,i))||t.tk.some(i=>!own(R,p,i)||bld(R,i))){R.trade=null;return 'Сделка устарела'}
 a.cash+=t.tc-t.gc;p.cash+=t.gc-t.tc;
 const mv=(i,to)=>{R.B[i].o=to.id;if(R.B[i].m)to.cash-=Math.min(to.cash,Math.ceil(price(i)/2*.1))};t.gp.forEach(i=>mv(i,p));t.tk.forEach(i=>mv(i,a));
 R.trade=null;lg(R,`Сделка ${a.name} ↔ ${p.name} совершена`)},
tradeX(R,p){const t=R.trade;if(!t||(t.to!=p.id&&t.from!=p.id))return 'Нет';R.trade=null;lg(R,'Сделка отклонена')}};
const ER=s=>typeof s=='string'?s.slice(0,40):'';
io.on('connection',s=>{let R,p;
 const attach=(code,name,tok)=>{R=rooms[code];if(!R)return 'Комната не найдена';tok=ER(tok);if(!tok)return 'Нет токена';
  p=R.P.find(x=>x.tok==tok);if(!p){if(R.ph!='lobby')return 'Игра уже идёт';if(R.P.length>=8)return 'Комната заполнена (8)';
   let ci=0;while(R.P.some(x=>x.ci==ci))ci++;p={id:'u'+(++R.uid),tok,name:String(name||'Игрок').slice(0,16)||'Игрок',ready:0,cash:1500,pos:0,jail:0,jt:0,jf:[],out:0,on:1,ln:0,ci};R.P.push(p)}
  p.on=1;s.join(code);lg(R,`${p.name} в игре`);bc(R);return null};
 s.on('create',(m,ack)=>{let c;do c=Math.random().toString(36).slice(2,7).toUpperCase();while(rooms[c]);rooms[c]=mk(c);const e=attach(c,m&&m.name,m&&m.tok);ack&&ack({err:e,code:c,me:p&&p.id,board:T,HC})});
 s.on('join',(m,ack)=>{const e=attach(String(m&&m.code||'').toUpperCase(),m&&m.name,m&&m.tok);ack&&ack({err:e,code:R&&R.code,me:p&&p.id,board:T,HC})});
 s.on('ready',()=>{if(!R||R.ph!='lobby')return;p.ready=!p.ready;bc(R)});
 s.on('start',()=>{if(!R||R.ph!='lobby'||R.P[0]!==p||R.P.length<2||!R.P.every(x=>x.ready))return;
  shuf(R.P);R.dk.c=shuf(CH.map((_,i)=>i));R.dk.k=shuf(CC.map((_,i)=>i));R.ph='play';R.t=0;R.tp='roll';lg(R,'Игра началась');bc(R)});
 s.on('act',(m,ack)=>{if(!R||!p||R.ph!='play'||!m||!A[m.a]||p.out)return ack&&ack({err:'Недоступно'});
  if(!(m.n>p.ln))return ack&&ack({err:'dup'});p.ln=m.n;
  const e=A[m.a](R,p,m);R.debt&&settle(R);if(!e)bc(R);ack&&ack({err:e||null})});
 s.on('disconnect',()=>{if(R&&p){p.on=0;lg(R,`${p.name} отключился`);if(R.pend&&R.pend.t=='auc')aucEnd(R);bc(R)}})});
srv.listen(process.env.PORT||3000,()=>console.log('Monopoly Napoli: http://localhost:'+(process.env.PORT||3000)));
